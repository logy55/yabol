import {Box2dPhysics} from '../vendor/marble-roulette/physics-box2d';
import {stages} from '../vendor/marble-roulette/data/maps';
import {ProgressMap} from '../vendor/marble-roulette/progressMap';
import {zoomZoneIntensity} from '../vendor/marble-roulette/zoomZone';
export function seededRandom(seed:number){let state=seed>>>0;return()=>{state=(state+0x6d2b79f5)>>>0;let t=state;t=Math.imul(t^(t>>>15),t|1);t^=t+Math.imul(t^(t>>>7),t|61);return((t^(t>>>14))>>>0)/4294967296;};}
export async function simulateMarbles(count:number,seed:number,{wasmBinary,signal,yieldControl=async()=>{},mapIndex=0}:{wasmBinary?:Uint8Array,signal?:AbortSignal,yieldControl?:()=>Promise<void>,mapIndex?:number}={}){
 if(!Number.isInteger(count)||count<2||count>12||!Number.isInteger(seed)||!stages[mapIndex])throw Error('Invalid marble simulation');
 const physics=new Box2dPhysics(seededRandom(seed)),stage=stages[mapIndex];
 await physics.init(wasmBinary);physics.createStage(stage);
 const progressMap=ProgressMap.for(stage),alive=new Set(Array.from({length:count},(_,i)=>i)),previous=Array.from({length:count},()=>({x:0,y:0})),stuck=Array(count).fill(0),keys=Array(count).fill(undefined),order:number[]=[],arrivals=Array(count).fill(Infinity),frames:any[]=[];
 const rows=Math.ceil(count/10);for(let i=0;i<count;i++)physics.createMarble(i,10.25+(i%10)*.6,rows-Math.floor(i/10));physics.start();
 const entities=physics.getEntities().map(({body,...entity}:any)=>entity),entityIds=new Map(physics.getEntities().map((e:any,i:number)=>[e.body,i]));
 let time=0,timeScale=1,ranked=[...alive],lastStanding:number|null=null;
 const capture=(intensity=0,focusOnRival=false)=>{const positions=new Float32Array(count*4),angles=new Float32Array(entities.length).fill(NaN);for(const id of alive){const p=physics.getMarblePosition(id);positions.set([p.x,p.y,p.angle,1],id*4);}for(const entity of physics.getEntities())angles[entityIds.get((entity as any).body)!]=entity.angle;frames.push({time,positions,angles,ranked:[...ranked],intensity,focusOnRival});};
 capture();
 try{
  for(let step=1;step<=30000&&alive.size;step++){
   if(step%400===0){if(signal?.aborted)throw new DOMException('Aborted','AbortError');await yieldControl();}
   const delta=.01*timeScale;physics.step(delta);time=step/100;const crossed:{id:number,fraction:number}[]=[];
   for(const id of alive){const p=physics.getMarblePosition(id),last=previous[id],distance=(p.x-last.x)**2+(p.y-last.y)**2;stuck[id]=distance<.00001*timeScale*timeScale?stuck[id]+10:0;if(stuck[id]>5000){physics.shakeMarble(id);stuck[id]=0;}if(p.y>stage.goalY)crossed.push({id,fraction:(stage.goalY-last.y)/Math.max(.000001,p.y-last.y)});previous[id]={x:p.x,y:p.y};const raw=progressMap.distanceAt(p.x,p.y);keys[id]=keys[id]===undefined?raw:keys[id]+(raw-keys[id])*(1-Math.exp(-delta/.4));}
   crossed.sort((a,b)=>a.fraction-b.fraction||a.id-b.id);for(const entry of crossed){order.push(entry.id);arrivals[entry.id]=time;alive.delete(entry.id);physics.removeMarble(entry.id);}
   ranked=ranked.filter(id=>alive.has(id));for(let i=1;i<ranked.length;i++){const id=ranked[i];let j=i;while(j>0&&keys[id]+.25<keys[ranked[j-1]]){ranked[j]=ranked[j-1];j--;}ranked[j]=id;}
   const target=ranked.at(-1),rival=ranked.at(-2),zones=stage.zoomZones?.length?stage.zoomZones:null;
   const intensityOf=(id:number|undefined)=>{if(id===undefined)return 0;const p=previous[id];return zones?zoomZoneIntensity(zones,p.x,p.y):Math.max(0,1-Math.abs(stage.zoomY-p.y)/5);};
   const focusOnRival=intensityOf(rival)>intensityOf(target),focus=focusOnRival?rival:target,intensity=intensityOf(focus);
   timeScale=1;if(alive.size>1&&focus!==undefined){const distance=Math.abs(stage.zoomY-previous[focus].y);if(zones&&intensity>0)timeScale=Math.max(.2,1-intensity);else if(!zones&&distance<5&&previous[focus].y>stage.zoomY-6)timeScale=Math.max(.2,distance/5);}
   capture(intensity,focusOnRival);
   // Upstream also settles the last rank once only one marble remains.
   if(alive.size===1&&order.length===count-1){lastStanding=ranked[0];order.push(lastStanding);arrivals[lastStanding]=time;break;}
  }
  if(alive.size>1)throw Error('This map did not finish within five minutes');
  return{count,seed,mapIndex,stage,entities,frames,order,arrivals,duration:time,goalY:stage.goalY,rescued:0,lastStanding};
 }finally{physics.clearMarbles();physics.clear();}
}
