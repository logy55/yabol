import {Box2dPhysics} from '../vendor/marble-roulette/physics-box2d';
import {stages} from '../vendor/marble-roulette/data/maps';

export function seededRandom(seed:number){
  let state=seed>>>0;
  return ()=>{state=(state+0x6d2b79f5)>>>0;let t=state;t=Math.imul(t^(t>>>15),t|1);t^=t+Math.imul(t^(t>>>7),t|61);return ((t^(t>>>14))>>>0)/4294967296;};
}
export async function simulateMarbles(count:number,seed:number,{wasmBinary,signal,yieldControl=async()=>{}}:{wasmBinary?:Uint8Array,signal?:AbortSignal,yieldControl?:()=>Promise<void>}={}){
  if(!Number.isInteger(count)||count<2||count>12||!Number.isInteger(seed))throw Error('Invalid marble simulation');
  const random=seededRandom(seed),physics=new Box2dPhysics(random),stage=stages[0];
  await physics.init(wasmBinary);physics.createStage(stage);
  const alive=new Set(Array.from({length:count},(_,i)=>i)),previous=Array.from({length:count},()=>({x:0,y:0})),stuck=Array(count).fill(0),order:number[]=[],arrivals=Array(count).fill(Infinity),frames:any[]=[];
  const rows=Math.ceil(count/10);
  for(let i=0;i<count;i++)physics.createMarble(i,10.25+(i%10)*0.6,rows-Math.floor(i/10));
  physics.start();
  let time=0;
  const capture=()=>{const positions=new Float32Array(count*4);for(let i=0;i<count;i++){const p=physics.getMarblePosition(i);positions.set([p.x,p.y,p.angle,alive.has(i)?1:0],i*4);}frames.push({time,positions,entities:physics.getEntities()});};
  capture();
  for(let step=1;step<=20000&&alive.size;step++){
    if(step%500===0){if(signal?.aborted)throw new DOMException('Aborted','AbortError');await yieldControl();}
    physics.step(.01);time=step/100;
    const crossed:{id:number,fraction:number}[]=[];
    for(const id of alive){
      const p=physics.getMarblePosition(id),last=previous[id],distance=(p.x-last.x)**2+(p.y-last.y)**2;
      stuck[id]=distance<.00001?stuck[id]+10:0;
      if(stuck[id]>5000){physics.shakeMarble(id);stuck[id]=0;}
      if(p.y>stage.goalY)crossed.push({id,fraction:(stage.goalY-last.y)/Math.max(.000001,p.y-last.y)});
      previous[id]={x:p.x,y:p.y};
    }
    crossed.sort((a,b)=>a.fraction-b.fraction||a.id-b.id);
    for(const entry of crossed){order.push(entry.id);arrivals[entry.id]=time;alive.delete(entry.id);physics.removeMarble(entry.id);}
    if(step%5===0||!alive.size)capture();
  }
  // Rescue an exceptionally trapped marble without allowing a stalled room. Server ranking is unchanged.
  const rescued=alive.size;
  if(rescued){
    const remaining=[...alive].sort((a,b)=>previous[b].y-previous[a].y||a-b),initial=remaining.map(id=>physics.getMarblePosition(id));
    for(let step=1;step<=60;step++){
      time+=.05;const positions=new Float32Array(frames.at(-1).positions);
      remaining.forEach((id,index)=>{const p=initial[index],progress=Math.min(1,step/(40+index));positions.set([p.x,p.y+(stage.goalY+2-p.y)*progress,p.angle,progress<1?1:0],id*4);if(progress===1&&alive.has(id)){arrivals[id]=time;order.push(id);alive.delete(id);}});
      frames.push({time,positions,entities:physics.getEntities()});
    }
  }
  physics.clearMarbles();physics.clear();
  return {count,seed,frames,order,arrivals,duration:time,goalY:stage.goalY,rescued};
}
