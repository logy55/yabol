import {simulateMarbles} from './simulation';

const colours=['#63b5ff','#ffca6a','#7de1ba','#dda0fb','#ff8eab','#64d7e6','#d9d87c','#a7b6ff','#ffaf76','#79d2b5','#c6a5ed','#e6b8c4'];
export async function prepareMarbleMovie(count:number,seed:number,signal?:AbortSignal){
  return simulateMarbles(count,seed,{signal,yieldControl:()=>new Promise(resolve=>setTimeout(resolve,0))});
}
export function playMarbleMovie(canvas:HTMLCanvasElement,movie:Awaited<ReturnType<typeof simulateMarbles>>,round:any,getProgress:()=>number,onArrivals:(indices:number[])=>void){
  const context=canvas.getContext('2d')!;
  let stopped=false,frameId=0,lastArrivals=-1;
  const ranks=Array(movie.count);movie.order.forEach((id,rank)=>{ranks[id]=rank;});
  const playerFor=(id:number)=>round.players[round.ranking[ranks[id]]];
  function draw(){
    if(stopped)return;
    const progress=Math.min(1,Math.max(0,getProgress())),time=movie.duration*progress;
    const index=Math.min(movie.frames.length-1,Math.floor(time/.05)),frame=movie.frames[index];
    const arrived=movie.order.filter(id=>movie.arrivals[id]<=time);
    if(arrived.length!==lastArrivals){lastArrivals=arrived.length;onArrivals(round.ranking.slice(0,arrived.length));}
    const bounds=canvas.getBoundingClientRect(),ratio=Math.min(2,devicePixelRatio||1),width=Math.max(280,bounds.width),height=Math.max(360,bounds.height);
    if(canvas.width!==Math.round(width*ratio)||canvas.height!==Math.round(height*ratio)){canvas.width=Math.round(width*ratio);canvas.height=Math.round(height*ratio);}
    context.setTransform(ratio,0,0,ratio,0,0);context.clearRect(0,0,width,height);
    const gradient=context.createLinearGradient(0,0,0,height);gradient.addColorStop(0,'#172a43');gradient.addColorStop(1,'#0f1d31');context.fillStyle=gradient;context.fillRect(0,0,width,height);
    const active=Array.from({length:movie.count},(_,id)=>id).filter(id=>frame.positions[id*4+3]);
    const leading=active.length?Math.max(...active.map(id=>frame.positions[id*4+1])):movie.goalY;
    const scale=Math.min(width/25,height/22),viewHeight=height/scale,cameraY=Math.max(viewHeight/2-1,Math.min(movie.goalY-viewHeight/2+3,leading+2));
    context.save();context.translate(width/2,height/2);context.scale(scale,scale);context.translate(-12.5,-cameraY);
    context.strokeStyle='#32465e';context.lineWidth=.03;
    for(let x=0;x<=25;x+=2){context.beginPath();context.moveTo(x,cameraY-viewHeight/2);context.lineTo(x,cameraY+viewHeight/2);context.stroke();}
    for(const entity of frame.entities){
      const shape=entity.shape;context.save();context.translate(entity.x,entity.y);context.rotate(entity.angle);context.strokeStyle=shape.color||'#7fbed9';context.fillStyle=shape.color||'#7fbed9';context.lineWidth=.13;context.shadowColor=shape.bloomColor||'#5fa5d0';context.shadowBlur=5;
      context.beginPath();if(shape.type==='circle'){context.arc(0,0,shape.radius,0,Math.PI*2);context.fill();}
      else if(shape.type==='box'){context.rotate(shape.rotation||0);context.fillRect(-shape.width,-shape.height,shape.width*2,shape.height*2);}
      else if(shape.type==='polyline'){shape.points.forEach((p:number[],i:number)=>i?context.lineTo(p[0],p[1]):context.moveTo(p[0],p[1]));context.stroke();}context.restore();
    }
    context.strokeStyle='#f6d88a';context.lineWidth=.12;context.setLineDash([.35,.25]);context.beginPath();context.moveTo(0,movie.goalY);context.lineTo(25,movie.goalY);context.stroke();context.setLineDash([]);
    for(const id of active){const p=frame.positions,offset=id*4,x=p[offset],y=p[offset+1],rank=ranks[id],colour=colours[round.ranking[rank]%colours.length],player=playerFor(id);
      context.save();context.translate(x,y);context.shadowColor=colour;context.shadowBlur=10;context.fillStyle=colour;context.strokeStyle='#e9f2ff';context.lineWidth=.07;context.beginPath();context.arc(0,0,.29,0,Math.PI*2);context.fill();context.stroke();context.shadowBlur=0;
      context.rotate(p[offset+2]);context.strokeStyle='#ffffff80';context.lineWidth=.045;context.beginPath();context.moveTo(-.2,0);context.lineTo(.2,0);context.stroke();context.rotate(-p[offset+2]);
      context.font='600 .48px NanumSquareRound, sans-serif';context.textAlign='center';context.lineWidth=.12;context.strokeStyle='#12233f';context.fillStyle='#fff';const name=String(player.name).slice(0,12);context.strokeText(name,0,-.65);context.fillText(name,0,-.65);context.restore();
    }
    context.restore();context.fillStyle='#d5e3f2';context.font='13px NanumSquareRound, sans-serif';context.textAlign='left';context.fillText(`도착 ${arrived.length} / ${movie.count}`,16,25);
    if(progress<1)frameId=requestAnimationFrame(draw);else onArrivals(round.ranking);
  }
  draw();return()=>{stopped=true;cancelAnimationFrame(frameId);};
}
